bot.onText(/\/admin/, (msg) => {
    const chatId = msg.chat.id;

    // Check if user is an admin
    if (!isAdmin(chatId)) {
        bot.sendMessage(
            chatId,
            "🚫 *Unauthorized access.* You are not an admin.",
        );
        return;
    }

    // Ask for the redeem code and amount
    bot.sendMessage(
        chatId,
        "🔑 Please enter the redeem code and amount in the format: `CODE,AMOUNT`",
        {
            parse_mode: "Markdown",
        },
    );

    bot.once("message", (msg) => {
        const input = msg.text.split(",");
        const code = input[0]?.trim();
        const amount = parseInt(input[1]?.trim());

        if (!code || isNaN(amount)) {
            bot.sendMessage(
                chatId,
                "❌ Invalid input. Please use the format: `CODE,AMOUNT`.",
            );
            return;
        }

        // Save the redeem code
        redeemCodes[code] = amount;
        saveData();

        bot.sendMessage(
            chatId,
            `✅ Redeem code '${code}' added with amount ${amount}.`,
        );
    });
});

// Helper function to check if user is admin
function isAdmin(chatId) {
    const ADMIN_CHAT_IDS = [
        /* Add admin chat IDs here */
    ];
    return ADMIN_CHAT_IDS.includes(chatId);
}
